FactoryGirl.define do
  factory :cheer do
    
  end

end
