require 'rails_helper'

RSpec.describe UserCommentsController, :type => :controller do

end
