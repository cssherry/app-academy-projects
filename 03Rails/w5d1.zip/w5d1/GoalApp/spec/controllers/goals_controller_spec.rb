require 'rails_helper'

RSpec.describe GoalsController, :type => :controller do

end
