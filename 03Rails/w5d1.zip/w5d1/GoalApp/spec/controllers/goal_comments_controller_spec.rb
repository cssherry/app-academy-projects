require 'rails_helper'

RSpec.describe GoalCommentsController, :type => :controller do

end
